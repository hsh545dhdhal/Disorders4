# دليل الإعدادات - Discord Voice Tracker Bot

هذا الدليل يشرح كيفية تخصيص وإعداد البوت حسب احتياجاتك.

## متغيرات البيئة 🔧

### المتغيرات الأساسية (مطلوبة)

#### Discord Bot

```env
DISCORD_TOKEN=your_token_here
```
- **الوصف:** رمز البوت من Discord Developer Portal
- **كيفية الحصول عليها:** 
  1. اذهب إلى [Discord Developer Portal](https://discord.com/developers/applications)
  2. اختر تطبيقك
  3. اذهب إلى "Bot" وانقر "Copy" تحت TOKEN

```env
DISCORD_CLIENT_ID=your_client_id
DISCORD_CLIENT_SECRET=your_client_secret
```
- **الوصف:** معرف التطبيق والسر
- **الموقع:** OAuth2 > General

#### قاعدة البيانات

```env
DATABASE_URL=mysql://user:password@localhost:3306/database_name
```
- **الصيغة:** `mysql://[user]:[password]@[host]:[port]/[database]`
- **مثال:** `mysql://bot_user:strong_password@localhost:3306/discord_bot_db`

### المتغيرات الاختيارية

#### LLM (للتحليلات الذكية)

```env
LLM_API_KEY=sk-proj-your-key-here
LLM_MODEL=gpt-4
```

**الخيارات:**
- `gpt-4` - النموذج الأفضل (أبطأ وأغلى)
- `gpt-3.5-turbo` - نموذج سريع وأرخص (الموصى به)
- `gpt-4-turbo` - توازن بين الجودة والسرعة

**الحصول على المفتاح:**
1. اذهب إلى [OpenAI Platform](https://platform.openai.com/api-keys)
2. أنشئ مفتاح API جديد
3. انسخه إلى ملف `.env`

#### AWS S3 (لتخزين الصور)

```env
AWS_ACCESS_KEY_ID=AKIAIOSFODNN7EXAMPLE
AWS_SECRET_ACCESS_KEY=wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY
AWS_S3_BUCKET=discord-bot-stats
AWS_S3_REGION=us-east-1
```

**الحصول على البيانات:**
1. اذهب إلى [AWS Console](https://console.aws.amazon.com)
2. اذهب إلى IAM > Users
3. أنشئ مستخدماً جديداً
4. أضف صلاحيات AmazonS3FullAccess
5. أنشئ Access Key
6. أنشئ دلو S3 جديد

### إعدادات البوت

```env
STATS_PUBLISH_HOUR=12
```
- **الوصف:** الساعة التي يتم نشر الإحصائيات فيها (0-23)
- **الافتراضي:** 12 (الظهيرة)
- **أمثلة:**
  - `0` = منتصف الليل
  - `6` = 6 صباحاً
  - `12` = الظهيرة
  - `18` = 6 مساءً
  - `23` = 11 مساءً

```env
ADMIN_ROLE_ID=1234567890
```
- **الوصف:** معرف دور الأدمن (اختياري)
- **كيفية الحصول عليها:**
  1. في Discord، فعّل "Developer Mode" (User Settings > Advanced)
  2. انقر بزر الماوس الأيمن على الدور
  3. انقر "Copy Role ID"

## إعدادات Discord 🎮

### الصلاحيات المطلوبة

تأكد من أن البوت لديه هذه الصلاحيات:

| الصلاحية | الوصف |
|---------|-------|
| Send Messages | إرسال الرسائل |
| Read Messages | قراءة الرسائل |
| Manage Messages | حذف/تعديل الرسائل |
| Embed Links | إرسال embeds |
| Attach Files | إرسال الملفات (الصور) |
| Read Message History | قراءة السجل |
| View Channels | عرض القنوات |

### إضافة البوت إلى السيرفر

1. اذهب إلى [Discord Developer Portal](https://discord.com/developers/applications)
2. اختر تطبيقك
3. اذهب إلى "OAuth2" > "URL Generator"
4. اختر الصلاحيات:
   - `bot`
   - `applications.commands`
5. اختر الأذونات المطلوبة
6. انسخ الرابط وافتحه في متصفحك

### تخصيص حالة البوت

عدّل ملف `bot/index.ts`:

```typescript
// غيّر هذا السطر
client.user?.setActivity('الإحصائيات الأسبوعية 📊', { type: 'WATCHING' });

// إلى
client.user?.setActivity('أوامر /help', { type: 'LISTENING' });
// أو
client.user?.setActivity('الفويس', { type: 'PLAYING' });
```

**أنواع الحالات:**
- `PLAYING` - يلعب
- `STREAMING` - بث مباشر
- `LISTENING` - يستمع
- `WATCHING` - يشاهد

## إعدادات الإحصائيات 📊

### تخصيص الإحصائيات المحسوبة

عدّل ملف `bot/services/statisticsService.ts` لإضافة إحصائيات جديدة:

```typescript
// مثال: إضافة إحصائية جديدة
const totalParticipants = new Set(sessions.map(s => s.userId)).size;
```

### تخصيص صيغة الصورة

عدّل ملف `bot/services/imageGenerator.ts`:

```typescript
// غيّر الألوان
gradient.addColorStop(0, '#1a1a2e');  // اللون الأول
gradient.addColorStop(1, '#0f3460');  // اللون الثاني

// غيّر الخطوط
ctx.font = 'bold 80px Arial';  // حجم وخط العنوان

// غيّر الأيقونات
ctx.fillText('🏆 النجم', x, y);  // غيّر الأيقونة
```

### تخصيص رسائل LLM

عدّل ملف `bot/services/llmAnalysis.ts`:

```typescript
const prompt = `
أنت محلل إحصائيات Discord متخصص...
// غيّر الـ prompt حسب احتياجاتك
`;
```

## إعدادات قاعدة البيانات 🗄️

### نسخ احتياطي

```bash
# إنشاء نسخة احتياطية
mysqldump -u root -p discord_bot_db > backup.sql

# استعادة من نسخة احتياطية
mysql -u root -p discord_bot_db < backup.sql
```

### تنظيف البيانات القديمة

```bash
# حذف جلسات فويس أقدم من 3 أشهر
mysql -u root -p -e "DELETE FROM discord_bot_db.voice_sessions WHERE createdAt < DATE_SUB(NOW(), INTERVAL 3 MONTH);"
```

### مراقبة قاعدة البيانات

```bash
# عرض حجم قاعدة البيانات
mysql -u root -p -e "SELECT table_name, ROUND(((data_length + index_length) / 1024 / 1024), 2) AS size_mb FROM information_schema.TABLES WHERE table_schema = 'discord_bot_db';"
```

## إعدادات التطوير 🛠️

### تفعيل وضع التصحيح (Debug Mode)

أضف هذا إلى ملف `.env`:

```env
LOG_LEVEL=debug
NODE_ENV=development
```

### تشغيل الاختبارات

```bash
pnpm test
```

### التحقق من الأخطاء

```bash
pnpm check
```

### تنسيق الكود

```bash
pnpm format
```

## الأداء والتحسين ⚡

### تحسين قاعدة البيانات

```bash
# إضافة فهارس لتسريع الاستعلامات
mysql -u root -p discord_bot_db << EOF
CREATE INDEX idx_guild_user ON voice_sessions(guildId, userId);
CREATE INDEX idx_created_at ON voice_sessions(createdAt);
CREATE INDEX idx_week_stats ON weekly_statistics(guildId, weekStart);
EOF
```

### تحسين الذاكرة

عدّل ملف `bot/index.ts`:

```typescript
// قلل عدد الأحداث المحفوظة
client.setMaxListeners(10);
```

### تحسين السرعة

```bash
# استخدم Node.js بوضع الإنتاج
NODE_ENV=production pnpm bot:start
```

## الأمان 🔒

### حماية المفاتيح

⚠️ **لا تشارك ملف `.env` أبداً!**

```bash
# تأكد من أن .env في .gitignore
echo ".env" >> .gitignore
```

### استخدام مفاتيح منفصلة

استخدم مفاتيح مختلفة للتطوير والإنتاج:

```env
# للتطوير
DISCORD_TOKEN=dev_token_here

# للإنتاج (استخدم متغيرات البيئة من النظام)
```

### تحديث المكتبات

```bash
# التحقق من التحديثات
pnpm outdated

# تحديث المكتبات
pnpm update
```

## استكشاف المشاكل 🐛

### البوت يستهلك ذاكرة كثيرة

**الحل:**
1. تحقق من عدد الأحداث المسجلة
2. أغلق الاتصالات غير المستخدمة
3. قلل عدد الجلسات المحفوظة

### الإحصائيات غير دقيقة

**الحل:**
1. تحقق من أن جميع الجلسات محفوظة بشكل صحيح
2. تحقق من حسابات الساعات
3. أعد تعيين البيانات باستخدام `/reset`

### الصور لا تُنشر

**الحل:**
1. تحقق من بيانات AWS S3
2. تحقق من صلاحيات الدلو
3. تحقق من أن القناة محددة

## الدعم والمساعدة 💬

للمزيد من المساعدة:
- اقرأ [README.md](./README.md)
- اقرأ [INSTALL.md](./INSTALL.md)
- افتح Issue في المستودع

---

**استمتع بتخصيص بوتك! 🎨**
