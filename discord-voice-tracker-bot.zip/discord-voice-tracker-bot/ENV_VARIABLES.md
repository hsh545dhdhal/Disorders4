# متغيرات البيئة المطلوبة - Discord Voice Tracker Bot

قم بإنشاء ملف `.env` في جذر المشروع وأضف المتغيرات التالية:

## Discord Bot Configuration
```
DISCORD_TOKEN=your_discord_bot_token_here
DISCORD_CLIENT_ID=your_client_id_here
DISCORD_CLIENT_SECRET=your_client_secret_here
```

**كيفية الحصول عليها:**
1. اذهب إلى [Discord Developer Portal](https://discord.com/developers/applications)
2. أنشئ تطبيق جديد أو اختر تطبيقاً موجوداً
3. اذهب إلى "Bot" وانقر "Add Bot"
4. انسخ "TOKEN" - هذا هو `DISCORD_TOKEN`
5. اذهب إلى "OAuth2" > "General" وانسخ "Client ID" و "Client Secret"

## Database Configuration
```
DATABASE_URL=mysql://user:password@localhost:3306/discord_bot_db
```

**ملاحظة:** قاعدة البيانات تم إعدادها بالفعل في المشروع

## AWS S3 Configuration (لتخزين صور الإحصائيات)
```
AWS_ACCESS_KEY_ID=your_aws_access_key
AWS_SECRET_ACCESS_KEY=your_aws_secret_key
AWS_S3_BUCKET=your_s3_bucket_name
AWS_S3_REGION=us-east-1
```

**كيفية الحصول عليها:**
1. اذهب إلى [AWS Console](https://console.aws.amazon.com)
2. اذهب إلى IAM > Users وأنشئ مستخدماً جديداً
3. أضف الصلاحيات: AmazonS3FullAccess
4. انسخ Access Key ID و Secret Access Key
5. أنشئ دلو S3 جديد وانسخ اسمه

## LLM Configuration (للتحليلات الذكية)
```
LLM_API_KEY=your_llm_api_key
LLM_MODEL=gpt-4
```

**خيارات:**
- **OpenAI:** احصل على المفتاح من [OpenAI Platform](https://platform.openai.com/api-keys)
  - النماذج المدعومة: `gpt-4`, `gpt-3.5-turbo`
- **خدمات أخرى:** يمكن استخدام أي خدمة LLM متوافقة مع OpenAI API

## Bot Settings
```
ADMIN_ROLE_ID=your_admin_role_id
STATS_PUBLISH_HOUR=12
```

- `ADMIN_ROLE_ID`: معرف دور الأدمن في Discord (اختياري - للتحكم في الأوامر)
- `STATS_PUBLISH_HOUR`: الساعة التي تريد نشر الإحصائيات فيها (0-23، الافتراضي: 12)

## Server Configuration
```
PORT=3000
NODE_ENV=development
```

- `PORT`: المنفذ الذي سيعمل عليه السيرفر
- `NODE_ENV`: بيئة التطوير (`development` أو `production`)

## Logging
```
LOG_LEVEL=info
```

- مستويات السجل: `debug`, `info`, `warn`, `error`

---

## مثال على ملف .env كامل

```env
# Discord Bot
DISCORD_TOKEN=MTk4NjIyNDgzNzU4OTQ1Nzky.Clwa7A.l7rH9tXcxd_SAZvxHqr4XgQkeW4
DISCORD_CLIENT_ID=198622483758945792
DISCORD_CLIENT_SECRET=your_secret_here

# Database
DATABASE_URL=mysql://root:password@localhost:3306/discord_bot_db

# AWS S3
AWS_ACCESS_KEY_ID=AKIAIOSFODNN7EXAMPLE
AWS_SECRET_ACCESS_KEY=wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY
AWS_S3_BUCKET=discord-bot-stats
AWS_S3_REGION=us-east-1

# LLM
LLM_API_KEY=sk-proj-abc123...
LLM_MODEL=gpt-4

# Bot Settings
ADMIN_ROLE_ID=1234567890
STATS_PUBLISH_HOUR=12

# Server
PORT=3000
NODE_ENV=development

# Logging
LOG_LEVEL=info
```

---

## ملاحظات أمان مهمة

⚠️ **لا تشارك ملف `.env` أبداً** - يحتوي على بيانات حساسة
⚠️ **لا تضع المفاتيح في Git** - أضف `.env` إلى `.gitignore`
⚠️ **استخدم مفاتيح منفصلة للإنتاج** - لا تستخدم مفاتيح التطوير في الإنتاج
