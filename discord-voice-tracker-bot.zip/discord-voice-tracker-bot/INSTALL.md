# دليل التثبيت - Discord Voice Tracker Bot

هذا الدليل سيساعدك على تثبيت وتشغيل بوت Discord Voice Tracker بنجاح.

## المتطلبات الأساسية 📋

قبل البدء، تأكد من أن لديك:

- **Node.js** >= 18.0.0 ([تحميل](https://nodejs.org/))
- **npm** أو **pnpm** (يأتي مع Node.js)
- **MySQL** >= 5.7 أو **TiDB** (قاعدة بيانات)
- **Git** (اختياري - للاستنساخ)

### التحقق من التثبيت

```bash
# تحقق من إصدار Node.js
node --version

# تحقق من npm
npm --version

# أو إذا كنت تستخدم pnpm
pnpm --version
```

## خطوات التثبيت 🚀

### 1. استنساخ المستودع

```bash
# باستخدام Git
git clone <repository-url>
cd discord-voice-tracker-bot

# أو قم بتحميل الملفات مباشرة
```

### 2. تثبيت المكتبات

```bash
# باستخدام pnpm (الموصى به)
pnpm install

# أو باستخدام npm
npm install

# أو باستخدام yarn
yarn install
```

**ملاحظة:** قد تستغرق هذه الخطوة عدة دقائق حسب سرعة الإنترنت.

### 3. إعداد قاعدة البيانات

#### أ) إنشاء قاعدة بيانات MySQL

```bash
# تسجيل الدخول إلى MySQL
mysql -u root -p

# إنشاء قاعدة البيانات
CREATE DATABASE discord_bot_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

# إنشاء مستخدم (اختياري)
CREATE USER 'bot_user'@'localhost' IDENTIFIED BY 'strong_password';
GRANT ALL PRIVILEGES ON discord_bot_db.* TO 'bot_user'@'localhost';
FLUSH PRIVILEGES;

# الخروج
EXIT;
```

#### ب) إعداد متغيرات البيئة

```bash
# انسخ ملف ENV_VARIABLES.md
cp ENV_VARIABLES.md .env

# عدّل الملف وأضف بيانات اعتمادك
nano .env  # أو استخدم محرر نصي آخر
```

**مثال على ملف .env:**

```env
# Discord Bot
DISCORD_TOKEN=MTk4NjIyNDgzNzU4OTQ1Nzky.Clwa7A.l7rH9tXcxd_SAZvxHqr4XgQkeW4
DISCORD_CLIENT_ID=198622483758945792
DISCORD_CLIENT_SECRET=your_secret_here

# Database
DATABASE_URL=mysql://bot_user:strong_password@localhost:3306/discord_bot_db

# LLM (اختياري)
LLM_API_KEY=sk-proj-abc123...
LLM_MODEL=gpt-3.5-turbo

# AWS S3 (اختياري)
AWS_ACCESS_KEY_ID=AKIAIOSFODNN7EXAMPLE
AWS_SECRET_ACCESS_KEY=wJalrXUtnFEMI/K7MDENG...
AWS_S3_BUCKET=discord-bot-stats
AWS_S3_REGION=us-east-1

# Bot Settings
STATS_PUBLISH_HOUR=12
```

#### ج) دفع التغييرات إلى قاعدة البيانات

```bash
pnpm db:push
```

هذا الأمر سينشئ جميع الجداول المطلوبة تلقائياً.

### 4. إعداد Discord Bot

#### أ) إنشاء تطبيق في Discord Developer Portal

1. اذهب إلى [Discord Developer Portal](https://discord.com/developers/applications)
2. انقر على "New Application"
3. أدخل اسماً للتطبيق (مثل "Voice Tracker Bot")
4. انقر على "Create"

#### ب) إنشاء Bot

1. اذهب إلى قسم "Bot" في الشريط الجانبي
2. انقر على "Add Bot"
3. انقر على "Copy" تحت "TOKEN" - **هذا هو DISCORD_TOKEN**

#### ج) تفعيل الصلاحيات المطلوبة

1. اذهب إلى "OAuth2" > "General"
2. انسخ "Client ID" - **هذا هو DISCORD_CLIENT_ID**
3. انسخ "Client Secret" - **هذا هو DISCORD_CLIENT_SECRET**

#### د) تعيين الصلاحيات

1. اذهب إلى "OAuth2" > "URL Generator"
2. اختر الصلاحيات التالية:
   - `bot`
   - `applications.commands`
3. اختر الأذونات التالية:
   - `Send Messages`
   - `Read Messages/View Channels`
   - `Manage Messages`
   - `Embed Links`
   - `Attach Files`
   - `Read Message History`
4. انسخ الرابط المُنشأ وافتحه في متصفحك لإضافة البوت إلى السيرفر

### 5. تشغيل البوت

#### في بيئة التطوير

```bash
pnpm bot:dev
```

#### في بيئة الإنتاج

```bash
# بناء المشروع
pnpm build

# تشغيل البوت
pnpm bot:start
```

### 6. تشغيل لوحة التحكم (اختياري)

#### في بيئة التطوير

```bash
# في نافذة terminal منفصلة
pnpm dev
```

#### في بيئة الإنتاج

```bash
# بناء المشروع
pnpm build

# تشغيل السيرفر
pnpm start
```

## التحقق من التثبيت ✅

بعد تشغيل البوت، يجب أن ترى رسائل مشابهة لهذه:

```
✅ تم الاتصال بقاعدة البيانات بنجاح
✅ تم تحميل الأمر: setchannel
✅ تم تحميل الأمر: starting
✅ تم تحميل الأمر: hours
✅ تم تحميل الأمر: toptwo
✅ تم تحميل الأمر: stats
✅ تم تحميل الأمر: reset
✅ تم تحميل الحدث: voiceStateUpdate
✅ تم تحميل الحدث: ready
✅ البوت جاهز! تم تسجيل الدخول باسم: VoiceTracker#1234
⏰ تم جدولة نشر الإحصائيات: كل أحد الساعة 12:00
```

## الأوامر الأولى 🎮

بعد تشغيل البوت، استخدم هذه الأوامر في Discord:

```
/setchannel #channel-name    - تحديد قناة النشر
/starting                     - بدء تتبع الإحصائيات
/hours                        - عرض ترتيب الساعات
/stats                        - عرض جميع الإحصائيات
```

## استكشاف الأخطاء 🐛

### البوت لا يستجيب

**المشكلة:** البوت لا يرد على الأوامر

**الحل:**
1. تأكد من أن البوت لديه صلاحيات كافية في السيرفر
2. تحقق من أن الأمر مسجل بشكل صحيح
3. تحقق من السجلات (logs) للأخطاء

### خطأ في قاعدة البيانات

**المشكلة:** `Error: connect ECONNREFUSED`

**الحل:**
1. تأكد من أن MySQL يعمل
2. تحقق من بيانات الاتصال في ملف `.env`
3. تأكد من أن قاعدة البيانات موجودة

### خطأ في المكتبات

**المشكلة:** `Cannot find module 'discord.js'`

**الحل:**
```bash
# أعد تثبيت المكتبات
rm -rf node_modules
pnpm install
```

### خطأ في canvas

**المشكلة:** `gyp ERR! build error`

**الحل:**
```bash
# على Linux/Mac
pnpm add canvas --build-from-source

# على Windows
npm install --global windows-build-tools
pnpm add canvas --build-from-source
```

## الإعدادات المتقدمة ⚙️

### تغيير وقت النشر الأسبوعي

عدّل متغير البيئة:

```env
STATS_PUBLISH_HOUR=15  # 3 مساءً
```

### تفعيل LLM للتحليلات الذكية

أضف مفتاح OpenAI API:

```env
LLM_API_KEY=sk-proj-your-key-here
LLM_MODEL=gpt-4
```

### تفعيل تخزين الصور على S3

أضف بيانات AWS:

```env
AWS_ACCESS_KEY_ID=your_key
AWS_SECRET_ACCESS_KEY=your_secret
AWS_S3_BUCKET=your_bucket
AWS_S3_REGION=us-east-1
```

## الدعم والمساعدة 💬

إذا واجهت مشاكل:

1. تحقق من [README.md](./README.md) للمزيد من المعلومات
2. افتح Issue في المستودع
3. تحقق من السجلات (logs) للأخطاء التفصيلية

## الخطوة التالية 🎯

بعد التثبيت بنجاح:

1. استخدم `/setchannel` لتحديد قناة النشر
2. استخدم `/starting` لبدء التتبع
3. اجلس في قنوات الفويس واستمتع بالإحصائيات الأسبوعية!

---

**استمتع ببوتك! 🎉**
