# البدء السريع - Discord Voice Tracker Bot 🚀

هذا دليل سريع للبدء في 5 دقائق!

## الخطوات السريعة

### 1️⃣ تثبيت المكتبات
```bash
pnpm install
```

### 2️⃣ إعداد قاعدة البيانات
```bash
# إنشاء قاعدة البيانات
mysql -u root -p -e "CREATE DATABASE discord_bot_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"

# دفع الجداول
pnpm db:push
```

### 3️⃣ إعداد متغيرات البيئة
```bash
# انسخ الملف
cp ENV_VARIABLES.md .env

# عدّل الملف وأضف بيانات اعتمادك
nano .env
```

**المتغيرات الأساسية المطلوبة:**
```env
DISCORD_TOKEN=your_token_here
DISCORD_CLIENT_ID=your_client_id
DISCORD_CLIENT_SECRET=your_secret
DATABASE_URL=mysql://user:password@localhost:3306/discord_bot_db
```

### 4️⃣ تشغيل البوت
```bash
pnpm bot:dev
```

### 5️⃣ استخدم الأوامر
```
/setchannel #channel-name    - تحديد قناة النشر
/starting                     - بدء التتبع
/hours                        - عرض الساعات
```

## الحصول على بيانات Discord 🎮

### DISCORD_TOKEN
1. اذهب إلى https://discord.com/developers/applications
2. اختر تطبيقك > Bot
3. انقر Copy تحت TOKEN

### DISCORD_CLIENT_ID و DISCORD_CLIENT_SECRET
1. اذهب إلى OAuth2 > General
2. انسخ Client ID و Client Secret

## إضافة البوت إلى السيرفر

1. اذهب إلى OAuth2 > URL Generator
2. اختر: `bot` و `applications.commands`
3. اختر الأذونات: Send Messages, Embed Links, Attach Files
4. انسخ الرابط وافتحه

## المشاكل الشائعة 🐛

### "Cannot find module 'discord.js'"
```bash
pnpm install
```

### "connect ECONNREFUSED" (خطأ قاعدة البيانات)
```bash
# تأكد من أن MySQL يعمل
mysql -u root -p -e "SELECT 1;"
```

### البوت لا يستجيب
- تأكد من أن البوت لديه صلاحيات
- تحقق من أن الأمر مسجل بشكل صحيح
- تحقق من السجلات (logs)

## الخطوة التالية

اقرأ الملفات الكاملة:
- [README.md](./README.md) - التوثيق الشامل
- [INSTALL.md](./INSTALL.md) - دليل التثبيت المفصل
- [CONFIG.md](./CONFIG.md) - دليل الإعدادات

## نصائح مفيدة 💡

```bash
# تشغيل لوحة التحكم (في نافذة منفصلة)
pnpm dev

# الاختبارات
pnpm test

# التحقق من الأخطاء
pnpm check

# تنسيق الكود
pnpm format
```

---

**استمتع ببوتك! 🎉**
