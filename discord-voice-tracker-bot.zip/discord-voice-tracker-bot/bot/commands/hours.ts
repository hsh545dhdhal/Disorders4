import { SlashCommandBuilder, ChatInputCommandInteraction } from 'discord.js';
import { getTopActiveUsersForWeek } from '../services/database.js';

export default {
  data: new SlashCommandBuilder()
    .setName('hours')
    .setDescription('عرض ساعات الفويس لهذا الأسبوع')
    .addIntegerOption(option =>
      option
        .setName('limit')
        .setDescription('عدد الأشخاص المراد عرضهم (الافتراضي: 10)')
        .setMinValue(1)
        .setMaxValue(50)
    ),

  async execute(interaction: ChatInputCommandInteraction) {
    try {
      await interaction.deferReply();

      const limit = interaction.options.getInteger('limit') || 10;

      // Calculate week start and end
      const now = new Date();
      const weekStart = new Date(now);
      weekStart.setDate(now.getDate() - now.getDay());
      weekStart.setHours(0, 0, 0, 0);

      const weekEnd = new Date(weekStart);
      weekEnd.setDate(weekStart.getDate() + 7);

      // Get top users
      const topUsers = await getTopActiveUsersForWeek(
        interaction.guildId!,
        weekStart,
        weekEnd,
        limit
      );

      if (topUsers.length === 0) {
        await interaction.editReply({
          content: '❌ لا توجد بيانات لهذا الأسبوع',
        });
        return;
      }

      // Create leaderboard
      let leaderboard = '🏆 **ترتيب الساعات الأسبوعي**\n\n';
      topUsers.forEach((user, index) => {
        const medal = index === 0 ? '🥇' : index === 1 ? '🥈' : index === 2 ? '🥉' : `${index + 1}.`;
        leaderboard += `${medal} **${user.userName}** - ${user.hours} ساعة\n`;
      });

      leaderboard += `\n📅 الفترة: ${weekStart.toLocaleDateString('ar-SA')} - ${weekEnd.toLocaleDateString('ar-SA')}`;

      await interaction.editReply({
        content: leaderboard,
      });

      console.log(`✅ تم عرض ساعات الفويس للسيرفر ${interaction.guildId}`);
    } catch (error) {
      console.error('❌ خطأ في أمر hours:', error);
      await interaction.editReply({
        content: '❌ حدث خطأ أثناء تنفيذ الأمر',
      });
    }
  },
};
