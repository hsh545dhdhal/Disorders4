import { SlashCommandBuilder, ChatInputCommandInteraction } from 'discord.js';
import { getDatabase } from '../services/database.js';
import { voiceSessions } from '../../drizzle/schema.js';
import { eq } from 'drizzle-orm';

export default {
  data: new SlashCommandBuilder()
    .setName('reset')
    .setDescription('إعادة تعيين جميع الإحصائيات (للأدمن فقط)')
    .setDefaultMemberPermissions(8), // Require admin permission

  async execute(interaction: ChatInputCommandInteraction) {
    try {
      // Check if user is admin
      if (!interaction.memberPermissions?.has('Administrator')) {
        await interaction.reply({
          content: '❌ يجب أن تكون أدمن لاستخدام هذا الأمر',
          ephemeral: true,
        });
        return;
      }

      await interaction.deferReply({ ephemeral: true });

      const db = getDatabase();
      
      // Delete all voice sessions for this guild
      await db
        .delete(voiceSessions)
        .where(eq(voiceSessions.guildId, interaction.guildId!));

      await interaction.editReply({
        content: '✅ تم إعادة تعيين جميع الإحصائيات بنجاح',
      });

      console.log(`✅ تم إعادة تعيين الإحصائيات للسيرفر ${interaction.guildId}`);
    } catch (error) {
      console.error('❌ خطأ في أمر reset:', error);
      await interaction.editReply({
        content: '❌ حدث خطأ أثناء تنفيذ الأمر',
      });
    }
  },
};
