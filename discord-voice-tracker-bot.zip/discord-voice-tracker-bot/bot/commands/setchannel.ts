import { SlashCommandBuilder, ChatInputCommandInteraction, ChannelType } from 'discord.js';
import { upsertBotConfig } from '../services/database.js';

export default {
  data: new SlashCommandBuilder()
    .setName('setchannel')
    .setDescription('تحديد قناة نشر الإحصائيات الأسبوعية')
    .addChannelOption(option =>
      option
        .setName('channel')
        .setDescription('القناة المراد نشر الإحصائيات فيها')
        .setRequired(true)
        .addChannelTypes(ChannelType.GuildText)
    )
    .setDefaultMemberPermissions(8), // Require admin permission

  async execute(interaction: ChatInputCommandInteraction) {
    try {
      // Check if user is admin
      if (!interaction.memberPermissions?.has('Administrator')) {
        await interaction.reply({
          content: '❌ يجب أن تكون أدمن لاستخدام هذا الأمر',
          ephemeral: true,
        });
        return;
      }

      const channel = interaction.options.getChannel('channel');

      if (!channel || !channel.isTextBased()) {
        await interaction.reply({
          content: '❌ يجب أن تختار قناة نصية',
          ephemeral: true,
        });
        return;
      }

      // Save config to database
      await upsertBotConfig({
        guildId: interaction.guildId!,
        statsChannelId: channel.id,
      });

      await interaction.reply({
        content: `✅ تم تحديد قناة النشر: <#${channel.id}>`,
        ephemeral: true,
      });

      console.log(`✅ تم تحديد قناة الإحصائيات للسيرفر ${interaction.guildId} إلى ${channel.id}`);
    } catch (error) {
      console.error('❌ خطأ في أمر setchannel:', error);
      await interaction.reply({
        content: '❌ حدث خطأ أثناء تنفيذ الأمر',
        ephemeral: true,
      });
    }
  },
};
