import { SlashCommandBuilder, ChatInputCommandInteraction } from 'discord.js';
import { upsertBotConfig } from '../services/database.js';

export default {
  data: new SlashCommandBuilder()
    .setName('starting')
    .setDescription('بدء تتبع الإحصائيات الأسبوعية')
    .setDefaultMemberPermissions(8), // Require admin permission

  async execute(interaction: ChatInputCommandInteraction) {
    try {
      // Check if user is admin
      if (!interaction.memberPermissions?.has('Administrator')) {
        await interaction.reply({
          content: '❌ يجب أن تكون أدمن لاستخدام هذا الأمر',
          ephemeral: true,
        });
        return;
      }

      // Enable bot for this guild
      await upsertBotConfig({
        guildId: interaction.guildId!,
        isEnabled: 1,
      });

      await interaction.reply({
        content: '✅ تم بدء تتبع الإحصائيات! سيتم نشر الإحصائيات الأسبوعية كل أحد الساعة 12 ظهراً',
        ephemeral: true,
      });

      console.log(`✅ تم تفعيل البوت للسيرفر ${interaction.guildId}`);
    } catch (error) {
      console.error('❌ خطأ في أمر starting:', error);
      await interaction.reply({
        content: '❌ حدث خطأ أثناء تنفيذ الأمر',
        ephemeral: true,
      });
    }
  },
};
