import { SlashCommandBuilder, ChatInputCommandInteraction, EmbedBuilder } from 'discord.js';
import {
  getTopActiveUsersForWeek,
  getTopMutedUsersForWeek,
  getTopSpeakingUsersForWeek,
} from '../services/database.js';

export default {
  data: new SlashCommandBuilder()
    .setName('stats')
    .setDescription('عرض جميع الإحصائيات الأسبوعية'),

  async execute(interaction: ChatInputCommandInteraction) {
    try {
      await interaction.deferReply();

      // Calculate week start and end
      const now = new Date();
      const weekStart = new Date(now);
      weekStart.setDate(now.getDate() - now.getDay());
      weekStart.setHours(0, 0, 0, 0);

      const weekEnd = new Date(weekStart);
      weekEnd.setDate(weekStart.getDate() + 7);

      // Get statistics
      const topActive = await getTopActiveUsersForWeek(interaction.guildId!, weekStart, weekEnd, 1);
      const topMuted = await getTopMutedUsersForWeek(interaction.guildId!, weekStart, weekEnd, 1);
      const topSpeaking = await getTopSpeakingUsersForWeek(interaction.guildId!, weekStart, weekEnd, 1);

      const embed = new EmbedBuilder()
        .setColor(0xff6b6b)
        .setTitle('📊 إحصائيات الأسبوع')
        .setDescription(`الفترة: ${weekStart.toLocaleDateString('ar-SA')} - ${weekEnd.toLocaleDateString('ar-SA')}`)
        .addFields(
          {
            name: '🏆 أكثر نشاطاً',
            value: topActive[0]
              ? `**${topActive[0].userName}** - ${topActive[0].hours} ساعة`
              : 'لا توجد بيانات',
            inline: false,
          },
          {
            name: '🎤 أكثر متحدث',
            value: topSpeaking[0]
              ? `**${topSpeaking[0].userName}** - ${topSpeaking[0].hours} ساعة`
              : 'لا توجد بيانات',
            inline: false,
          },
          {
            name: '🔇 أكثر مستمع',
            value: topMuted[0]
              ? `**${topMuted[0].userName}** - ${topMuted[0].hours} ساعة`
              : 'لا توجد بيانات',
            inline: false,
          }
        )
        .setTimestamp();

      await interaction.editReply({
        embeds: [embed],
      });

      console.log(`✅ تم عرض الإحصائيات للسيرفر ${interaction.guildId}`);
    } catch (error) {
      console.error('❌ خطأ في أمر stats:', error);
      await interaction.editReply({
        content: '❌ حدث خطأ أثناء تنفيذ الأمر',
      });
    }
  },
};
