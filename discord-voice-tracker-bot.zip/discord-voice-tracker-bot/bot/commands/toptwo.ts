import { SlashCommandBuilder, ChatInputCommandInteraction, EmbedBuilder } from 'discord.js';
import { getTopActiveUsersForWeek } from '../services/database.js';

export default {
  data: new SlashCommandBuilder()
    .setName('toptwo')
    .setDescription('عرض أفضل شخصين هذا الأسبوع'),

  async execute(interaction: ChatInputCommandInteraction) {
    try {
      await interaction.deferReply();

      // Calculate week start and end
      const now = new Date();
      const weekStart = new Date(now);
      weekStart.setDate(now.getDate() - now.getDay());
      weekStart.setHours(0, 0, 0, 0);

      const weekEnd = new Date(weekStart);
      weekEnd.setDate(weekStart.getDate() + 7);

      // Get top 2 users
      const topUsers = await getTopActiveUsersForWeek(
        interaction.guildId!,
        weekStart,
        weekEnd,
        2
      );

      if (topUsers.length === 0) {
        await interaction.editReply({
          content: '❌ لا توجد بيانات لهذا الأسبوع',
        });
        return;
      }

      // Create embeds for top 2
      const embeds = [];

      if (topUsers[0]) {
        const embed1 = new EmbedBuilder()
          .setColor(0xffd700) // Gold
          .setTitle('🥇 المركز الأول')
          .setDescription(`**${topUsers[0].userName}**`)
          .addFields(
            { name: 'الساعات', value: `${topUsers[0].hours} ساعة`, inline: true },
            { name: 'الدقائق', value: `${topUsers[0].hours * 60} دقيقة`, inline: true }
          )
          .setTimestamp();
        embeds.push(embed1);
      }

      if (topUsers[1]) {
        const embed2 = new EmbedBuilder()
          .setColor(0xc0c0c0) // Silver
          .setTitle('🥈 المركز الثاني')
          .setDescription(`**${topUsers[1].userName}**`)
          .addFields(
            { name: 'الساعات', value: `${topUsers[1].hours} ساعة`, inline: true },
            { name: 'الدقائق', value: `${topUsers[1].hours * 60} دقيقة`, inline: true }
          )
          .setTimestamp();
        embeds.push(embed2);
      }

      await interaction.editReply({
        embeds,
      });

      console.log(`✅ تم عرض أفضل شخصين للسيرفر ${interaction.guildId}`);
    } catch (error) {
      console.error('❌ خطأ في أمر toptwo:', error);
      await interaction.editReply({
        content: '❌ حدث خطأ أثناء تنفيذ الأمر',
      });
    }
  },
};
