import { Client } from 'discord.js';

export default {
  name: 'ready',
  once: true,
  async execute(client: Client) {
    console.log(`✅ البوت جاهز! تم تسجيل الدخول باسم: ${client.user?.tag}`);
    console.log(`📊 عدد السيرفرات: ${client.guilds.cache.size}`);
    
    // Set bot status
    client.user?.setActivity('الإحصائيات الأسبوعية 📊', { type: 'WATCHING' });
  },
};
