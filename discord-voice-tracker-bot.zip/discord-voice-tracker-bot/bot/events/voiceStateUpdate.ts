import { VoiceState } from 'discord.js';
import {
  handleVoiceJoin,
  handleVoiceLeave,
  handleMicStateChange,
  handleChannelSwitch,
} from '../services/voiceTracker.js';

export default {
  name: 'voiceStateUpdate',
  async execute(oldState: VoiceState, newState: VoiceState) {
    try {
      // User joined voice channel
      if (!oldState.channel && newState.channel) {
        await handleVoiceJoin(newState);
      }
      // User left voice channel
      else if (oldState.channel && !newState.channel) {
        await handleVoiceLeave(oldState);
      }
      // User switched channels
      else if (oldState.channel && newState.channel && oldState.channel.id !== newState.channel.id) {
        await handleChannelSwitch(newState);
      }
      // Microphone state changed
      else if (
        oldState.channel &&
        newState.channel &&
        (oldState.selfMute !== newState.selfMute || oldState.selfDeaf !== newState.selfDeaf)
      ) {
        await handleMicStateChange(newState);
      }
    } catch (error) {
      console.error('❌ خطأ في معالجة حدث voiceStateUpdate:', error);
    }
  },
};
