import { Client, GatewayIntentBits, Collection, REST, Routes } from 'discord.js';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import cron from 'node-cron';

// Load environment variables
dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Initialize Discord client
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.DirectMessages,
    GatewayIntentBits.MessageContent,
  ],
});

// Store commands
client.commands = new Collection();

// Load commands
async function loadCommands() {
  const commandsPath = path.join(__dirname, 'commands');
  const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.ts') || file.endsWith('.js'));

  for (const file of commandFiles) {
    const filePath = path.join(commandsPath, file);
    try {
      const command = await import(filePath);
      if (command.default?.data && command.default?.execute) {
        client.commands.set(command.default.data.name, command.default);
        console.log(`✅ تم تحميل الأمر: ${command.default.data.name}`);
      }
    } catch (error) {
      console.error(`❌ خطأ في تحميل الأمر ${file}:`, error);
    }
  }
}

// Load events
async function loadEvents() {
  const eventsPath = path.join(__dirname, 'events');
  const eventFiles = fs.readdirSync(eventsPath).filter(file => file.endsWith('.ts') || file.endsWith('.js'));

  for (const file of eventFiles) {
    const filePath = path.join(eventsPath, file);
    try {
      const event = await import(filePath);
      if (event.default?.name && event.default?.execute) {
        if (event.default.once) {
          client.once(event.default.name, (...args) => event.default.execute(...args));
        } else {
          client.on(event.default.name, (...args) => event.default.execute(...args));
        }
        console.log(`✅ تم تحميل الحدث: ${event.default.name}`);
      }
    } catch (error) {
      console.error(`❌ خطأ في تحميل الحدث ${file}:`, error);
    }
  }
}

// Register slash commands
async function registerSlashCommands() {
  const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN!);
  const commands = Array.from(client.commands.values()).map(cmd => cmd.data.toJSON());

  try {
    console.log(`🔄 جاري تسجيل ${commands.length} أمر...`);
    await rest.put(
      Routes.applicationCommands(process.env.DISCORD_CLIENT_ID!),
      { body: commands }
    );
    console.log('✅ تم تسجيل جميع الأوامر بنجاح');
  } catch (error) {
    console.error('❌ خطأ في تسجيل الأوامر:', error);
  }
}

// Initialize bot
async function initialize() {
  try {
    console.log('🚀 جاري بدء البوت...');
    
    // Load commands and events
    await loadCommands();
    await loadEvents();
    
    // Login to Discord
    await client.login(process.env.DISCORD_TOKEN);
    
    // Register slash commands after login
    client.once('ready', async () => {
      await registerSlashCommands();
      console.log(`✅ البوت جاهز! تم تسجيل الدخول باسم: ${client.user?.tag}`);
      
      // Initialize cron jobs for weekly statistics
      initializeCronJobs();
    });
  } catch (error) {
    console.error('❌ خطأ في بدء البوت:', error);
    process.exit(1);
  }
}

// Initialize cron jobs
function initializeCronJobs() {
  const publishHour = parseInt(process.env.STATS_PUBLISH_HOUR || '12');
  
  // Run every Sunday at specified hour
  const cronExpression = `0 ${publishHour} * * 0`;
  
  cron.schedule(cronExpression, async () => {
    console.log('📊 جاري نشر الإحصائيات الأسبوعية...');
    // This will be implemented in the statistics service
  });
  
  console.log(`⏰ تم جدولة نشر الإحصائيات: كل أحد الساعة ${publishHour}:00`);
}

// Handle interactions (slash commands)
client.on('interactionCreate', async (interaction) => {
  if (!interaction.isChatInputCommand()) return;

  const command = client.commands.get(interaction.commandName);
  if (!command) {
    console.error(`❌ لم يتم العثور على الأمر: ${interaction.commandName}`);
    return;
  }

  try {
    await command.execute(interaction);
  } catch (error) {
    console.error(`❌ خطأ في تنفيذ الأمر ${interaction.commandName}:`, error);
    if (interaction.replied || interaction.deferred) {
      await interaction.followUp({ content: '❌ حدث خطأ أثناء تنفيذ الأمر', ephemeral: true });
    } else {
      await interaction.reply({ content: '❌ حدث خطأ أثناء تنفيذ الأمر', ephemeral: true });
    }
  }
});

// Start the bot
initialize();

// Handle process termination
process.on('SIGINT', async () => {
  console.log('\n🛑 جاري إيقاف البوت...');
  await client.destroy();
  process.exit(0);
});

export default client;
