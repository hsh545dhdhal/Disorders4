import { drizzle } from 'drizzle-orm/mysql2';
import mysql from 'mysql2/promise';
import {
  voiceSessions,
  weeklyStatistics,
  botConfig,
  userStats,
  type VoiceSession,
  type InsertVoiceSession,
  type WeeklyStatistics,
  type InsertWeeklyStatistics,
  type BotConfig,
  type InsertBotConfig,
  type UserStats,
  type InsertUserStats,
} from '../../drizzle/schema.js';
import { eq, and, gte, lte, desc, sql } from 'drizzle-orm';

let db: ReturnType<typeof drizzle> | null = null;

/**
 * Initialize database connection
 */
export async function initializeDatabase() {
  try {
    const connection = await mysql.createConnection(process.env.DATABASE_URL!);
    db = drizzle(connection);
    console.log('✅ تم الاتصال بقاعدة البيانات بنجاح');
    return db;
  } catch (error) {
    console.error('❌ خطأ في الاتصال بقاعدة البيانات:', error);
    throw error;
  }
}

/**
 * Get database instance
 */
export function getDatabase() {
  if (!db) {
    throw new Error('Database not initialized');
  }
  return db;
}

/**
 * Save voice session
 */
export async function saveVoiceSession(session: InsertVoiceSession) {
  const database = getDatabase();
  const result = await database.insert(voiceSessions).values(session);
  return result;
}

/**
 * Update voice session
 */
export async function updateVoiceSession(
  sessionId: number,
  updates: Partial<VoiceSession>
) {
  const database = getDatabase();
  return await database
    .update(voiceSessions)
    .set(updates)
    .where(eq(voiceSessions.id, sessionId));
}

/**
 * Get active voice session for user
 */
export async function getActiveVoiceSession(userId: string, guildId: string) {
  const database = getDatabase();
  const result = await database
    .select()
    .from(voiceSessions)
    .where(
      and(
        eq(voiceSessions.userId, userId),
        eq(voiceSessions.guildId, guildId),
        eq(voiceSessions.leftAt, null)
      )
    )
    .limit(1);
  return result[0] || null;
}

/**
 * Get voice sessions for week
 */
export async function getVoiceSessionsForWeek(
  guildId: string,
  weekStart: Date,
  weekEnd: Date
) {
  const database = getDatabase();
  return await database
    .select()
    .from(voiceSessions)
    .where(
      and(
        eq(voiceSessions.guildId, guildId),
        gte(voiceSessions.joinedAt, weekStart),
        lte(voiceSessions.joinedAt, weekEnd)
      )
    );
}

/**
 * Calculate user statistics for week
 */
export async function calculateUserStatsForWeek(
  guildId: string,
  userId: string,
  weekStart: Date,
  weekEnd: Date
) {
  const database = getDatabase();
  
  const sessions = await database
    .select()
    .from(voiceSessions)
    .where(
      and(
        eq(voiceSessions.guildId, guildId),
        eq(voiceSessions.userId, userId),
        gte(voiceSessions.joinedAt, weekStart),
        lte(voiceSessions.joinedAt, weekEnd)
      )
    );

  let totalSeconds = 0;
  let mutedSeconds = 0;
  let speakingSeconds = 0;

  for (const session of sessions) {
    const duration = session.durationSeconds || 0;
    totalSeconds += duration;
    
    if (session.isDeafened) {
      mutedSeconds += duration;
    } else if (session.isMicOn) {
      speakingSeconds += duration;
    }
  }

  return {
    totalHours: Math.floor(totalSeconds / 3600),
    totalSessions: sessions.length,
    mutedHours: Math.floor(mutedSeconds / 3600),
    speakingHours: Math.floor(speakingSeconds / 3600),
  };
}

/**
 * Get top active users for week
 */
export async function getTopActiveUsersForWeek(
  guildId: string,
  weekStart: Date,
  weekEnd: Date,
  limit: number = 10
) {
  const database = getDatabase();
  
  const result = await database
    .select({
      userId: voiceSessions.userId,
      userName: voiceSessions.userName,
      totalSeconds: sql<number>`SUM(${voiceSessions.durationSeconds})`,
    })
    .from(voiceSessions)
    .where(
      and(
        eq(voiceSessions.guildId, guildId),
        gte(voiceSessions.joinedAt, weekStart),
        lte(voiceSessions.joinedAt, weekEnd)
      )
    )
    .groupBy(voiceSessions.userId)
    .orderBy(desc(sql<number>`SUM(${voiceSessions.durationSeconds})`))
    .limit(limit);

  return result.map(r => ({
    userId: r.userId,
    userName: r.userName,
    hours: Math.floor((r.totalSeconds || 0) / 3600),
  }));
}

/**
 * Get top muted users for week
 */
export async function getTopMutedUsersForWeek(
  guildId: string,
  weekStart: Date,
  weekEnd: Date,
  limit: number = 10
) {
  const database = getDatabase();
  
  const result = await database
    .select({
      userId: voiceSessions.userId,
      userName: voiceSessions.userName,
      totalSeconds: sql<number>`SUM(${voiceSessions.durationSeconds})`,
    })
    .from(voiceSessions)
    .where(
      and(
        eq(voiceSessions.guildId, guildId),
        eq(voiceSessions.isDeafened, 1),
        gte(voiceSessions.joinedAt, weekStart),
        lte(voiceSessions.joinedAt, weekEnd)
      )
    )
    .groupBy(voiceSessions.userId)
    .orderBy(desc(sql<number>`SUM(${voiceSessions.durationSeconds})`))
    .limit(limit);

  return result.map(r => ({
    userId: r.userId,
    userName: r.userName,
    hours: Math.floor((r.totalSeconds || 0) / 3600),
  }));
}

/**
 * Get top speaking users for week
 */
export async function getTopSpeakingUsersForWeek(
  guildId: string,
  weekStart: Date,
  weekEnd: Date,
  limit: number = 10
) {
  const database = getDatabase();
  
  const result = await database
    .select({
      userId: voiceSessions.userId,
      userName: voiceSessions.userName,
      totalSeconds: sql<number>`SUM(${voiceSessions.durationSeconds})`,
    })
    .from(voiceSessions)
    .where(
      and(
        eq(voiceSessions.guildId, guildId),
        eq(voiceSessions.isMicOn, 1),
        gte(voiceSessions.joinedAt, weekStart),
        lte(voiceSessions.joinedAt, weekEnd)
      )
    )
    .groupBy(voiceSessions.userId)
    .orderBy(desc(sql<number>`SUM(${voiceSessions.durationSeconds})`))
    .limit(limit);

  return result.map(r => ({
    userId: r.userId,
    userName: r.userName,
    hours: Math.floor((r.totalSeconds || 0) / 3600),
  }));
}

/**
 * Save weekly statistics
 */
export async function saveWeeklyStatistics(stats: InsertWeeklyStatistics) {
  const database = getDatabase();
  return await database.insert(weeklyStatistics).values(stats);
}

/**
 * Get bot config for guild
 */
export async function getBotConfig(guildId: string) {
  const database = getDatabase();
  const result = await database
    .select()
    .from(botConfig)
    .where(eq(botConfig.guildId, guildId))
    .limit(1);
  return result[0] || null;
}

/**
 * Create or update bot config
 */
export async function upsertBotConfig(config: InsertBotConfig) {
  const database = getDatabase();
  const existing = await getBotConfig(config.guildId!);
  
  if (existing) {
    return await database
      .update(botConfig)
      .set(config)
      .where(eq(botConfig.guildId, config.guildId!));
  } else {
    return await database.insert(botConfig).values(config);
  }
}

/**
 * Update user stats
 */
export async function updateUserStats(
  guildId: string,
  userId: string,
  stats: Partial<UserStats>
) {
  const database = getDatabase();
  const existing = await database
    .select()
    .from(userStats)
    .where(
      and(
        eq(userStats.guildId, guildId),
        eq(userStats.userId, userId)
      )
    )
    .limit(1);

  if (existing.length > 0) {
    return await database
      .update(userStats)
      .set(stats)
      .where(
        and(
          eq(userStats.guildId, guildId),
          eq(userStats.userId, userId)
        )
      );
  } else {
    return await database.insert(userStats).values({
      guildId,
      userId,
      ...stats,
    });
  }
}

/**
 * Get user stats
 */
export async function getUserStats(guildId: string, userId: string) {
  const database = getDatabase();
  const result = await database
    .select()
    .from(userStats)
    .where(
      and(
        eq(userStats.guildId, guildId),
        eq(userStats.userId, userId)
      )
    )
    .limit(1);
  return result[0] || null;
}

/**
 * Get all weekly statistics for guild
 */
export async function getWeeklyStatisticsForGuild(guildId: string, limit: number = 10) {
  const database = getDatabase();
  return await database
    .select()
    .from(weeklyStatistics)
    .where(eq(weeklyStatistics.guildId, guildId))
    .orderBy(desc(weeklyStatistics.createdAt))
    .limit(limit);
}
