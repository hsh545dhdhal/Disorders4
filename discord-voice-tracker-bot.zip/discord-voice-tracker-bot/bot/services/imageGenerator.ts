import { createCanvas, loadImage } from 'canvas';
import fetch from 'node-fetch';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

interface StatisticsData {
  topActive: {
    name: string;
    hours: number;
    avatar?: string;
  };
  topMuted: {
    name: string;
    hours: number;
    avatar?: string;
  };
  topSpeaking: {
    name: string;
    hours: number;
    avatar?: string;
  };
  topPair: {
    user1: string;
    user2: string;
    sessions: number;
  };
  longestSession: {
    name: string;
    hours: number;
    avatar?: string;
  };
  weekStart: Date;
  weekEnd: Date;
}

/**
 * Download user avatar from Discord
 */
async function downloadAvatar(avatarUrl: string): Promise<Buffer> {
  try {
    const response = await fetch(avatarUrl);
    return await response.buffer();
  } catch (error) {
    console.error('❌ خطأ في تحميل الصورة:', error);
    throw error;
  }
}

/**
 * Draw rounded rectangle
 */
function drawRoundedRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  width: number,
  height: number,
  radius: number
) {
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.lineTo(x + width - radius, y);
  ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
  ctx.lineTo(x + width, y + height - radius);
  ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
  ctx.lineTo(x + radius, y + height);
  ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
  ctx.lineTo(x, y + radius);
  ctx.quadraticCurveTo(x, y, x + radius, y);
  ctx.closePath();
}

/**
 * Generate statistics image
 */
export async function generateStatisticsImage(stats: StatisticsData): Promise<Buffer> {
  try {
    const canvas = createCanvas(1920, 1080);
    const ctx = canvas.getContext('2d');

    // Draw gradient background
    const gradient = ctx.createLinearGradient(0, 0, 1920, 1080);
    gradient.addColorStop(0, '#1a1a2e');
    gradient.addColorStop(0.5, '#16213e');
    gradient.addColorStop(1, '#0f3460');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, 1920, 1080);

    // Add decorative elements
    ctx.fillStyle = 'rgba(255, 107, 107, 0.1)';
    ctx.fillRect(0, 0, 1920, 200);

    // Title
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 80px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('📊 إحصائيات الأسبوع', 960, 120);

    // Week range
    ctx.font = '32px Arial';
    ctx.fillStyle = '#b0b0b0';
    const weekText = `${stats.weekStart.toLocaleDateString('ar-SA')} - ${stats.weekEnd.toLocaleDateString('ar-SA')}`;
    ctx.fillText(weekText, 960, 170);

    // Draw stat boxes
    const boxWidth = 350;
    const boxHeight = 280;
    const startX = 150;
    const startY = 300;
    const spacing = 50;

    const stats_array = [
      {
        emoji: '🎤',
        title: 'أكثر متحدث',
        name: stats.topSpeaking.name,
        value: `${stats.topSpeaking.hours} ساعة`,
        color: '#ff6b6b',
      },
      {
        emoji: '🔇',
        title: 'أكثر مستمع',
        name: stats.topMuted.name,
        value: `${stats.topMuted.hours} ساعة`,
        color: '#4ecdc4',
      },
      {
        emoji: '⏱️',
        title: 'أطول جلسة',
        name: stats.longestSession.name,
        value: `${stats.longestSession.hours} ساعة`,
        color: '#ffe66d',
      },
      {
        emoji: '👥',
        title: 'أفضل ثنائي',
        name: `${stats.topPair.user1} & ${stats.topPair.user2}`,
        value: `${stats.topPair.sessions} جلسة`,
        color: '#95e1d3',
      },
    ];

    for (let i = 0; i < stats_array.length; i++) {
      const stat = stats_array[i];
      const x = startX + (i % 2) * (boxWidth + spacing + 150);
      const y = startY + Math.floor(i / 2) * (boxHeight + spacing);

      // Draw box
      ctx.fillStyle = stat.color;
      ctx.globalAlpha = 0.15;
      drawRoundedRect(ctx, x, y, boxWidth, boxHeight, 20);
      ctx.fill();
      ctx.globalAlpha = 1;

      // Draw border
      ctx.strokeStyle = stat.color;
      ctx.lineWidth = 3;
      drawRoundedRect(ctx, x, y, boxWidth, boxHeight, 20);
      ctx.stroke();

      // Draw emoji
      ctx.font = '60px Arial';
      ctx.fillStyle = stat.color;
      ctx.textAlign = 'center';
      ctx.fillText(stat.emoji, x + boxWidth / 2, y + 70);

      // Draw title
      ctx.font = 'bold 28px Arial';
      ctx.fillStyle = '#ffffff';
      ctx.fillText(stat.title, x + boxWidth / 2, y + 130);

      // Draw name
      ctx.font = '24px Arial';
      ctx.fillStyle = '#e0e0e0';
      ctx.fillText(stat.name, x + boxWidth / 2, y + 180);

      // Draw value
      ctx.font = 'bold 32px Arial';
      ctx.fillStyle = stat.color;
      ctx.fillText(stat.value, x + boxWidth / 2, y + 240);
    }

    // Draw top active user section (larger)
    const topActiveX = 1250;
    const topActiveY = 300;
    const topActiveWidth = 520;
    const topActiveHeight = 680;

    ctx.fillStyle = '#ff6b6b';
    ctx.globalAlpha = 0.15;
    drawRoundedRect(ctx, topActiveX, topActiveY, topActiveWidth, topActiveHeight, 20);
    ctx.fill();
    ctx.globalAlpha = 1;

    ctx.strokeStyle = '#ff6b6b';
    ctx.lineWidth = 3;
    drawRoundedRect(ctx, topActiveX, topActiveY, topActiveWidth, topActiveHeight, 20);
    ctx.stroke();

    // Top active title
    ctx.font = 'bold 36px Arial';
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'center';
    ctx.fillText('🏆 النجم', topActiveX + topActiveWidth / 2, topActiveY + 60);

    // Top active name
    ctx.font = 'bold 32px Arial';
    ctx.fillStyle = '#ff6b6b';
    ctx.fillText(stats.topActive.name, topActiveX + topActiveWidth / 2, topActiveY + 150);

    // Top active hours
    ctx.font = '48px Arial';
    ctx.fillStyle = '#ffffff';
    ctx.fillText(`${stats.topActive.hours} ساعة`, topActiveX + topActiveWidth / 2, topActiveY + 250);

    // Top active stats
    ctx.font = '24px Arial';
    ctx.fillStyle = '#b0b0b0';
    ctx.fillText('أكثر نشاطاً هذا الأسبوع', topActiveX + topActiveWidth / 2, topActiveY + 320);

    // Footer
    ctx.font = '20px Arial';
    ctx.fillStyle = '#707070';
    ctx.textAlign = 'center';
    ctx.fillText('Discord Voice Tracker Bot', 960, 1020);

    return canvas.toBuffer('image/png');
  } catch (error) {
    console.error('❌ خطأ في توليد الصورة:', error);
    throw error;
  }
}

/**
 * Save image to file
 */
export async function saveImageToFile(buffer: Buffer, filename: string): Promise<string> {
  try {
    const imagesDir = path.join(__dirname, '../../images');
    
    // Create directory if it doesn't exist
    if (!fs.existsSync(imagesDir)) {
      fs.mkdirSync(imagesDir, { recursive: true });
    }

    const filepath = path.join(imagesDir, filename);
    fs.writeFileSync(filepath, buffer);
    
    console.log(`✅ تم حفظ الصورة: ${filepath}`);
    return filepath;
  } catch (error) {
    console.error('❌ خطأ في حفظ الصورة:', error);
    throw error;
  }
}
