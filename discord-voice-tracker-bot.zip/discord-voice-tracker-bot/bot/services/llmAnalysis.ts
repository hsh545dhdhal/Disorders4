import axios from 'axios';

interface AnalysisData {
  topActive: string;
  topMuted: string;
  topSpeaking: string;
  topPair: string;
  longestSession: string;
  weekStart: string;
  weekEnd: string;
  totalParticipants: number;
}

/**
 * Generate AI analysis using LLM
 */
export async function generateAIAnalysis(data: AnalysisData): Promise<string> {
  try {
    if (!process.env.LLM_API_KEY) {
      console.warn('⚠️ لم يتم توفير مفتاح LLM API');
      return generateDefaultAnalysis(data);
    }

    const prompt = `
أنت محلل إحصائيات Discord متخصص. قم بتحليل البيانات التالية وأنشئ تقرير ذكي وممتع:

البيانات:
- أكثر شخص نشاطاً: ${data.topActive}
- أكثر شخص استماعاً (مايك مغلق): ${data.topMuted}
- أكثر شخص تحدثاً: ${data.topSpeaking}
- أفضل ثنائي: ${data.topPair}
- أطول جلسة: ${data.longestSession}
- الفترة الزمنية: من ${data.weekStart} إلى ${data.weekEnd}
- عدد المشاركين: ${data.totalParticipants}

اكتب تقرير قصير (3-4 جمل) بصيغة ودية وممتعة يتضمن:
1. ملاحظة عن أداء النجم
2. ملاحظة عن الثنائي الأفضل
3. تعليق عام عن النشاط الأسبوعي
4. تشجيع للمجموعة

استخدم الإيموجي بشكل معتدل.
    `;

    const response = await axios.post(
      'https://api.openai.com/v1/chat/completions',
      {
        model: process.env.LLM_MODEL || 'gpt-3.5-turbo',
        messages: [
          {
            role: 'system',
            content: 'أنت محلل إحصائيات Discord ودود ومتحمس.',
          },
          {
            role: 'user',
            content: prompt,
          },
        ],
        temperature: 0.7,
        max_tokens: 200,
      },
      {
        headers: {
          'Authorization': `Bearer ${process.env.LLM_API_KEY}`,
          'Content-Type': 'application/json',
        },
      }
    );

    const analysis = response.data.choices[0]?.message?.content || generateDefaultAnalysis(data);
    console.log('✅ تم توليد التحليل الذكي بنجاح');
    return analysis;
  } catch (error) {
    console.error('❌ خطأ في توليد التحليل الذكي:', error);
    return generateDefaultAnalysis(data);
  }
}

/**
 * Generate default analysis if LLM fails
 */
function generateDefaultAnalysis(data: AnalysisData): string {
  return `
🎉 **تقرير الأسبوع**

🏆 **النجم هذا الأسبوع:** ${data.topActive} - أظهر نشاطاً رائعاً وكان الأكثر حضوراً!

🎤 **أكثر متحدث:** ${data.topSpeaking} - لم يتوقف عن الحديث! 😄

🔇 **أكثر مستمع:** ${data.topMuted} - كان يستمع باهتمام!

👥 **أفضل ثنائي:** ${data.topPair} - ثنائي رائع هذا الأسبوع!

⏱️ **أطول جلسة:** ${data.longestSession} - قضى وقتاً رائعاً معنا!

شكراً لـ ${data.totalParticipants} مشاركين على نشاطهم! استمتعوا بالأسبوع القادم! 🎊
  `;
}

/**
 * Generate performance insights
 */
export async function generatePerformanceInsights(
  currentWeekStats: any,
  previousWeekStats: any
): Promise<string> {
  try {
    const improvements = [];

    // Compare top active users
    if (currentWeekStats.topActive.hours > (previousWeekStats?.topActive?.hours || 0)) {
      const increase = currentWeekStats.topActive.hours - (previousWeekStats?.topActive?.hours || 0);
      improvements.push(
        `📈 ${currentWeekStats.topActive.name} أظهر تحسناً ملحوظاً بزيادة ${increase} ساعة!`
      );
    }

    // Compare total participants
    if (currentWeekStats.totalParticipants > (previousWeekStats?.totalParticipants || 0)) {
      improvements.push(
        `👥 زيادة في عدد المشاركين بمقدار ${currentWeekStats.totalParticipants - (previousWeekStats?.totalParticipants || 0)} أشخاص!`
      );
    }

    // Compare speaking hours
    if (currentWeekStats.totalSpeakingHours > (previousWeekStats?.totalSpeakingHours || 0)) {
      improvements.push(
        `🎤 الجميع أكثر تحدثاً هذا الأسبوع! 🎉`
      );
    }

    return improvements.length > 0
      ? improvements.join('\n')
      : 'استمتعوا بأسبوع رائع معاً! 🌟';
  } catch (error) {
    console.error('❌ خطأ في توليد رؤى الأداء:', error);
    return 'شكراً على المشاركة! 🙏';
  }
}
