import {
  getVoiceSessionsForWeek,
  getTopActiveUsersForWeek,
  getTopMutedUsersForWeek,
  getTopSpeakingUsersForWeek,
  saveWeeklyStatistics,
} from './database.js';
import { generateStatisticsImage } from './imageGenerator.js';
import { generateAIAnalysis } from './llmAnalysis.js';
import { Client, TextChannel } from 'discord.js';

/**
 * Calculate pair interactions
 */
async function calculatePairInteractions(
  guildId: string,
  weekStart: Date,
  weekEnd: Date
): Promise<{ user1: string; user2: string; count: number }> {
  const sessions = await getVoiceSessionsForWeek(guildId, weekStart, weekEnd);
  
  const pairMap = new Map<string, number>();
  
  // Group sessions by time and channel
  const sessionsByTime = new Map<string, any[]>();
  
  for (const session of sessions) {
    const timeKey = `${session.channelId}-${Math.floor(session.joinedAt.getTime() / (15 * 60 * 1000))}`;
    if (!sessionsByTime.has(timeKey)) {
      sessionsByTime.set(timeKey, []);
    }
    sessionsByTime.get(timeKey)!.push(session);
  }
  
  // Count pairs
  for (const [, timeSessions] of sessionsByTime) {
    if (timeSessions.length >= 2) {
      for (let i = 0; i < timeSessions.length; i++) {
        for (let j = i + 1; j < timeSessions.length; j++) {
          const user1 = timeSessions[i].userId;
          const user2 = timeSessions[j].userId;
          const pairKey = [user1, user2].sort().join('-');
          pairMap.set(pairKey, (pairMap.get(pairKey) || 0) + 1);
        }
      }
    }
  }
  
  // Find top pair
  let topPair = { user1: 'Unknown', user2: 'Unknown', count: 0 };
  for (const [key, count] of pairMap) {
    if (count > topPair.count) {
      const [user1, user2] = key.split('-');
      topPair = { user1, user2, count };
    }
  }
  
  return topPair;
}

/**
 * Generate weekly statistics
 */
export async function generateWeeklyStatistics(
  client: Client,
  guildId: string,
  weekStart: Date,
  weekEnd: Date
) {
  try {
    console.log(`📊 جاري توليد الإحصائيات للفترة: ${weekStart.toLocaleDateString('ar-SA')} - ${weekEnd.toLocaleDateString('ar-SA')}`);

    // Get top users
    const topActive = await getTopActiveUsersForWeek(guildId, weekStart, weekEnd, 1);
    const topMuted = await getTopMutedUsersForWeek(guildId, weekStart, weekEnd, 1);
    const topSpeaking = await getTopSpeakingUsersForWeek(guildId, weekStart, weekEnd, 1);
    const topPair = await calculatePairInteractions(guildId, weekStart, weekEnd);

    // Get longest session
    const sessions = await getVoiceSessionsForWeek(guildId, weekStart, weekEnd);
    let longestSession = { userId: 'Unknown', userName: 'Unknown', hours: 0 };
    
    for (const session of sessions) {
      const hours = Math.floor((session.durationSeconds || 0) / 3600);
      if (hours > longestSession.hours) {
        longestSession = {
          userId: session.userId,
          userName: session.userName || 'Unknown',
          hours,
        };
      }
    }

    // Prepare statistics data
    const statsData = {
      topActive: {
        name: topActive[0]?.userName || 'Unknown',
        hours: topActive[0]?.hours || 0,
      },
      topMuted: {
        name: topMuted[0]?.userName || 'Unknown',
        hours: topMuted[0]?.hours || 0,
      },
      topSpeaking: {
        name: topSpeaking[0]?.userName || 'Unknown',
        hours: topSpeaking[0]?.hours || 0,
      },
      topPair: {
        user1: topPair.user1,
        user2: topPair.user2,
        sessions: topPair.count,
      },
      longestSession: {
        name: longestSession.userName,
        hours: longestSession.hours,
      },
      weekStart,
      weekEnd,
    };

    // Generate image
    console.log('🎨 جاري توليد صورة الإحصائيات...');
    const imageBuffer = await generateStatisticsImage(statsData);

    // Generate AI analysis
    console.log('🤖 جاري توليد التحليل الذكي...');
    const aiAnalysis = await generateAIAnalysis({
      topActive: statsData.topActive.name,
      topMuted: statsData.topMuted.name,
      topSpeaking: statsData.topSpeaking.name,
      topPair: `${statsData.topPair.user1} و ${statsData.topPair.user2}`,
      longestSession: statsData.longestSession.name,
      weekStart: weekStart.toLocaleDateString('ar-SA'),
      weekEnd: weekEnd.toLocaleDateString('ar-SA'),
      totalParticipants: new Set(sessions.map(s => s.userId)).size,
    });

    // Save to database
    const result = await saveWeeklyStatistics({
      guildId,
      weekStart,
      weekEnd,
      topActiveUser: topActive[0]?.userId,
      topActiveUserName: topActive[0]?.userName,
      topActiveHours: topActive[0]?.hours || 0,
      topMutedUser: topMuted[0]?.userId,
      topMutedUserName: topMuted[0]?.userName,
      topMutedHours: topMuted[0]?.hours || 0,
      topSpeakingUser: topSpeaking[0]?.userId,
      topSpeakingUserName: topSpeaking[0]?.userName,
      topSpeakingHours: topSpeaking[0]?.hours || 0,
      topPairUser1: topPair.user1,
      topPairUser2: topPair.user2,
      topPairCount: topPair.count,
      longestSessionUser: longestSession.userId,
      longestSessionUserName: longestSession.userName,
      longestSessionHours: longestSession.hours,
      aiAnalysis,
    });

    console.log('✅ تم حفظ الإحصائيات في قاعدة البيانات');

    return {
      imageBuffer,
      statsData,
      aiAnalysis,
    };
  } catch (error) {
    console.error('❌ خطأ في توليد الإحصائيات:', error);
    throw error;
  }
}

/**
 * Publish statistics to channel
 */
export async function publishStatisticsToChannel(
  client: Client,
  guildId: string,
  channelId: string,
  imageBuffer: Buffer,
  statsData: any,
  aiAnalysis: string
) {
  try {
    const guild = await client.guilds.fetch(guildId);
    const channel = await guild.channels.fetch(channelId) as TextChannel;

    if (!channel || !channel.isTextBased()) {
      throw new Error('القناة غير موجودة أو ليست قناة نصية');
    }

    // Create embed message
    const embed = {
      color: 0xff6b6b,
      title: '📊 إحصائيات الأسبوع',
      description: aiAnalysis,
      fields: [
        {
          name: '🏆 النجم',
          value: `${statsData.topActive.name} - ${statsData.topActive.hours} ساعة`,
          inline: true,
        },
        {
          name: '🎤 أكثر متحدث',
          value: `${statsData.topSpeaking.name} - ${statsData.topSpeaking.hours} ساعة`,
          inline: true,
        },
        {
          name: '🔇 أكثر مستمع',
          value: `${statsData.topMuted.name} - ${statsData.topMuted.hours} ساعة`,
          inline: true,
        },
        {
          name: '⏱️ أطول جلسة',
          value: `${statsData.longestSession.name} - ${statsData.longestSession.hours} ساعة`,
          inline: true,
        },
        {
          name: '👥 أفضل ثنائي',
          value: `${statsData.topPair.user1} و ${statsData.topPair.user2}`,
          inline: true,
        },
      ],
      timestamp: new Date().toISOString(),
    };

    // Send message with image
    const message = await channel.send({
      embeds: [embed],
      files: [
        {
          attachment: imageBuffer,
          name: 'statistics.png',
        },
      ],
    });

    console.log(`✅ تم نشر الإحصائيات في القناة ${channel.name}`);
    return message;
  } catch (error) {
    console.error('❌ خطأ في نشر الإحصائيات:', error);
    throw error;
  }
}
