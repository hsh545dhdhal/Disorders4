import { VoiceState } from 'discord.js';
import {
  saveVoiceSession,
  updateVoiceSession,
  getActiveVoiceSession,
  updateUserStats,
} from './database.js';

/**
 * Handle user joining voice channel
 */
export async function handleVoiceJoin(voiceState: VoiceState) {
  try {
    if (!voiceState.member || !voiceState.channel) return;

    const userId = voiceState.member.id;
    const guildId = voiceState.guild.id;
    const channelId = voiceState.channel.id;
    const userName = voiceState.member.user.username;

    // Check if user already has an active session
    const existingSession = await getActiveVoiceSession(userId, guildId);
    if (existingSession) {
      console.log(`⚠️ المستخدم ${userName} لديه جلسة نشطة بالفعل`);
      return;
    }

    // Create new voice session
    const session = await saveVoiceSession({
      guildId,
      userId,
      userName,
      channelId,
      joinedAt: new Date(),
      isMicOn: voiceState.selfMute ? 0 : 1,
      isDeafened: voiceState.selfDeaf ? 1 : 0,
    });

    console.log(`✅ المستخدم ${userName} انضم إلى الفويس`);
  } catch (error) {
    console.error('❌ خطأ في معالجة انضمام المستخدم:', error);
  }
}

/**
 * Handle user leaving voice channel
 */
export async function handleVoiceLeave(voiceState: VoiceState) {
  try {
    if (!voiceState.member) return;

    const userId = voiceState.member.id;
    const guildId = voiceState.guild.id;
    const userName = voiceState.member.user.username;

    // Get active session
    const session = await getActiveVoiceSession(userId, guildId);
    if (!session) {
      console.log(`⚠️ لم يتم العثور على جلسة نشطة للمستخدم ${userName}`);
      return;
    }

    // Calculate session duration
    const now = new Date();
    const durationSeconds = Math.floor(
      (now.getTime() - session.joinedAt.getTime()) / 1000
    );

    // Update session with leave time and duration
    await updateVoiceSession(session.id, {
      leftAt: now,
      durationSeconds,
    });

    // Update user stats
    const durationHours = Math.floor(durationSeconds / 3600);
    await updateUserStats(guildId, userId, {
      totalSessions: (session.id as any) + 1, // Increment sessions
      totalHours: durationHours,
    });

    console.log(
      `✅ المستخدم ${userName} غادر الفويس (المدة: ${Math.floor(durationSeconds / 60)} دقيقة)`
    );
  } catch (error) {
    console.error('❌ خطأ في معالجة مغادرة المستخدم:', error);
  }
}

/**
 * Handle microphone state change
 */
export async function handleMicStateChange(voiceState: VoiceState) {
  try {
    if (!voiceState.member) return;

    const userId = voiceState.member.id;
    const guildId = voiceState.guild.id;
    const userName = voiceState.member.user.username;

    // Get active session
    const session = await getActiveVoiceSession(userId, guildId);
    if (!session) return;

    const isMicOn = voiceState.selfMute ? 0 : 1;
    const isDeafened = voiceState.selfDeaf ? 1 : 0;

    // Update session
    await updateVoiceSession(session.id, {
      isMicOn,
      isDeafened,
    });

    const status = voiceState.selfMute ? '🔇 مغلق' : '🎤 مفتوح';
    console.log(`🔄 حالة المايك للمستخدم ${userName}: ${status}`);
  } catch (error) {
    console.error('❌ خطأ في معالجة تغيير حالة المايك:', error);
  }
}

/**
 * Handle channel switch
 */
export async function handleChannelSwitch(voiceState: VoiceState) {
  try {
    if (!voiceState.member) return;

    const userId = voiceState.member.id;
    const guildId = voiceState.guild.id;
    const userName = voiceState.member.user.username;

    // Get active session
    const session = await getActiveVoiceSession(userId, guildId);
    if (!session) return;

    // Calculate duration in previous channel
    const now = new Date();
    const durationSeconds = Math.floor(
      (now.getTime() - session.joinedAt.getTime()) / 1000
    );

    // End previous session
    await updateVoiceSession(session.id, {
      leftAt: now,
      durationSeconds,
    });

    // Create new session in new channel
    if (voiceState.channel) {
      await saveVoiceSession({
        guildId,
        userId,
        userName,
        channelId: voiceState.channel.id,
        joinedAt: new Date(),
        isMicOn: voiceState.selfMute ? 0 : 1,
        isDeafened: voiceState.selfDeaf ? 1 : 0,
      });

      console.log(
        `🔄 المستخدم ${userName} انتقل إلى قناة أخرى (المدة السابقة: ${Math.floor(durationSeconds / 60)} دقيقة)`
      );
    }
  } catch (error) {
    console.error('❌ خطأ في معالجة تبديل القناة:', error);
  }
}
