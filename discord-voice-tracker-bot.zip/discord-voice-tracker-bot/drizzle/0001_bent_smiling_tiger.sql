CREATE TABLE `bot_config` (
	`id` int AUTO_INCREMENT NOT NULL,
	`guildId` varchar(64) NOT NULL,
	`statsChannelId` varchar(64),
	`isEnabled` int DEFAULT 1,
	`publishDay` varchar(20) DEFAULT 'sunday',
	`publishHour` int DEFAULT 12,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `bot_config_id` PRIMARY KEY(`id`),
	CONSTRAINT `bot_config_guildId_unique` UNIQUE(`guildId`)
);
--> statement-breakpoint
CREATE TABLE `user_stats` (
	`id` int AUTO_INCREMENT NOT NULL,
	`guildId` varchar(64) NOT NULL,
	`userId` varchar(64) NOT NULL,
	`userName` text,
	`totalHours` int DEFAULT 0,
	`totalSessions` int DEFAULT 0,
	`mutedHours` int DEFAULT 0,
	`speakingHours` int DEFAULT 0,
	`lastUpdated` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `user_stats_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `voice_sessions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`guildId` varchar(64) NOT NULL,
	`userId` varchar(64) NOT NULL,
	`userName` text,
	`channelId` varchar(64) NOT NULL,
	`joinedAt` timestamp NOT NULL,
	`leftAt` timestamp,
	`durationSeconds` int DEFAULT 0,
	`isMicOn` int DEFAULT 1,
	`isDeafened` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `voice_sessions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `weekly_statistics` (
	`id` int AUTO_INCREMENT NOT NULL,
	`guildId` varchar(64) NOT NULL,
	`weekStart` timestamp NOT NULL,
	`weekEnd` timestamp NOT NULL,
	`topActiveUser` varchar(64),
	`topActiveUserName` text,
	`topActiveHours` int DEFAULT 0,
	`topMutedUser` varchar(64),
	`topMutedUserName` text,
	`topMutedHours` int DEFAULT 0,
	`topSpeakingUser` varchar(64),
	`topSpeakingUserName` text,
	`topSpeakingHours` int DEFAULT 0,
	`topPairUser1` varchar(64),
	`topPairUser2` varchar(64),
	`topPairCount` int DEFAULT 0,
	`longestSessionUser` varchar(64),
	`longestSessionUserName` text,
	`longestSessionHours` int DEFAULT 0,
	`imageUrl` text,
	`messageId` varchar(64),
	`aiAnalysis` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `weekly_statistics_id` PRIMARY KEY(`id`)
);
