import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Voice session tracking table
 * يتتبع جلسات الفويس لكل عضو
 */
export const voiceSessions = mysqlTable("voice_sessions", {
  id: int("id").autoincrement().primaryKey(),
  guildId: varchar("guildId", { length: 64 }).notNull(),
  userId: varchar("userId", { length: 64 }).notNull(),
  userName: text("userName"),
  channelId: varchar("channelId", { length: 64 }).notNull(),
  joinedAt: timestamp("joinedAt").notNull(),
  leftAt: timestamp("leftAt"),
  durationSeconds: int("durationSeconds").default(0),
  isMicOn: int("isMicOn").default(1),
  isDeafened: int("isDeafened").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type VoiceSession = typeof voiceSessions.$inferSelect;
export type InsertVoiceSession = typeof voiceSessions.$inferInsert;

/**
 * Weekly statistics table
 * يحتفظ بالإحصائيات الأسبوعية
 */
export const weeklyStatistics = mysqlTable("weekly_statistics", {
  id: int("id").autoincrement().primaryKey(),
  guildId: varchar("guildId", { length: 64 }).notNull(),
  weekStart: timestamp("weekStart").notNull(),
  weekEnd: timestamp("weekEnd").notNull(),
  topActiveUser: varchar("topActiveUser", { length: 64 }),
  topActiveUserName: text("topActiveUserName"),
  topActiveHours: int("topActiveHours").default(0),
  topMutedUser: varchar("topMutedUser", { length: 64 }),
  topMutedUserName: text("topMutedUserName"),
  topMutedHours: int("topMutedHours").default(0),
  topSpeakingUser: varchar("topSpeakingUser", { length: 64 }),
  topSpeakingUserName: text("topSpeakingUserName"),
  topSpeakingHours: int("topSpeakingHours").default(0),
  topPairUser1: varchar("topPairUser1", { length: 64 }),
  topPairUser2: varchar("topPairUser2", { length: 64 }),
  topPairCount: int("topPairCount").default(0),
  longestSessionUser: varchar("longestSessionUser", { length: 64 }),
  longestSessionUserName: text("longestSessionUserName"),
  longestSessionHours: int("longestSessionHours").default(0),
  imageUrl: text("imageUrl"),
  messageId: varchar("messageId", { length: 64 }),
  aiAnalysis: text("aiAnalysis"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type WeeklyStatistics = typeof weeklyStatistics.$inferSelect;
export type InsertWeeklyStatistics = typeof weeklyStatistics.$inferInsert;

/**
 * Bot configuration table
 * إعدادات البوت لكل سيرفر
 */
export const botConfig = mysqlTable("bot_config", {
  id: int("id").autoincrement().primaryKey(),
  guildId: varchar("guildId", { length: 64 }).notNull().unique(),
  statsChannelId: varchar("statsChannelId", { length: 64 }),
  isEnabled: int("isEnabled").default(1),
  publishDay: varchar("publishDay", { length: 20 }).default("sunday"),
  publishHour: int("publishHour").default(12),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type BotConfig = typeof botConfig.$inferSelect;
export type InsertBotConfig = typeof botConfig.$inferInsert;

/**
 * User statistics cache table
 * تخزين مؤقت لإحصائيات المستخدم
 */
export const userStats = mysqlTable("user_stats", {
  id: int("id").autoincrement().primaryKey(),
  guildId: varchar("guildId", { length: 64 }).notNull(),
  userId: varchar("userId", { length: 64 }).notNull(),
  userName: text("userName"),
  totalHours: int("totalHours").default(0),
  totalSessions: int("totalSessions").default(0),
  mutedHours: int("mutedHours").default(0),
  speakingHours: int("speakingHours").default(0),
  lastUpdated: timestamp("lastUpdated").defaultNow().onUpdateNow().notNull(),
});

export type UserStats = typeof userStats.$inferSelect;
export type InsertUserStats = typeof userStats.$inferInsert;